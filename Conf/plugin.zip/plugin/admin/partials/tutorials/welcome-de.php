<button class="cf7cstmzr-close-welcome button button-primary">Überspringe das Handbuch und starte mit dem Gestalten</button> 
<hr>
<a href="https://design-for-contact-form-7-wow-styler.tawk.help/" target="_blank"> Hanbuch in einem neuen Tab/Fenster öffnen</a> Idee: Das Handbuch in einer Hälfte des Bildschirms und das cf7-Formular in der anderen Hälfte anzeigen zu lassen.
<iframe src="https://design-for-contact-form-7-wow-styler.tawk.help/" width="100%" height="800px"></iframe>
<a href="https://design-for-contact-form-7-wow-styler.tawk.help/" target="_blank"> Hanbuch in einem neuen Tab/Fenster öffnen</a> Idee: Das Handbuch in einer Hälfte des Bildschirms und das cf7-Formular in der anderen Hälfte anzeigen zu lassen.
<hr>
<button class="cf7cstmzr-close-welcome button button-primary">Starte mit dem Gestalten</button>
