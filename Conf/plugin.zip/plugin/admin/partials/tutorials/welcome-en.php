<button class="cf7cstmzr-close-welcome button button-primary">Skip tutorial and start styling</button> 
<hr>
<a href="https://design-for-contact-form-7-wow-styler.tawk.help/" target="_blank"> Open KB in a new tab/window</a> Idea: Have the KB in one half of the screen and the cf7 form in the other half.
<iframe src="https://design-for-contact-form-7-wow-styler.tawk.help/" width="100%" height="800px"></iframe>
<a href="https://design-for-contact-form-7-wow-styler.tawk.help/" target="_blank"> Open KB in a new tab/window</a> Idea: Have the KB in one half of the screen and the cf7 form in the other half.<hr>
<button class="cf7cstmzr-close-welcome button button-primary">Start styling</button>
